package com.example.navcomponents

data class CatsModel(
    val name: String,
    val imageUrl: String
)
