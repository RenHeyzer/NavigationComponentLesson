package com.example.navcomponents

interface OnItemClickListener {

    fun onClick(catsModel: CatsModel)
}